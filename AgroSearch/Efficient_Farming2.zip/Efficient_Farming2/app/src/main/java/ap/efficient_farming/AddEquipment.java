package ap.efficient_farming;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class AddEquipment extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    private Spinner spinnerType, spinnerMode;
    private static final String[] type = {"Tractor", "Baler", "Combine", "Plow","Mower","Planter","Sprayer"};
    private static final String[] mode = {"hour","day","week","month"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getSupportActionBar().hide();
        this.getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
        );
        setContentView(R.layout.activity_add_equipment);
        spinnerType = (Spinner) findViewById(R.id.typeSpinner);
        spinnerMode = (Spinner) findViewById(R.id.SpinnerMode);
        ArrayAdapter<String> adapterType = new ArrayAdapter<String>(AddEquipment.this,
                R.layout.spinner_item, type);
        ArrayAdapter<String> adapterMode = new ArrayAdapter<String>(AddEquipment.this,
                R.layout.spinner_item, mode);
        adapterType.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerType.setAdapter(adapterType);
        spinnerMode.setAdapter(adapterMode);
        spinnerType.setSelection(0);
        spinnerMode.setSelection(0);
        spinnerType.setOnItemSelectedListener(this);
        spinnerMode.setOnItemSelectedListener(this);
            }
    @Override
    public void onItemSelected(AdapterView<?> parent, View v, int position, long id) {

        switch (position) {
            case 0:
                // Whatever you want to happen when the first item gets selected
                break;
            case 1:
                // Whatever you want to happen when the second item gets selected
                break;
            case 2:
                // Whatever you want to happen when the third item gets selected
                break;
            case 3:
                //
                break;
            case 4:
                //
                break;
            case 5:
                //
                break;
            case 6:
                //
                break;
        }
    }
    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        // TODO Auto-generated method stub
    }

}
